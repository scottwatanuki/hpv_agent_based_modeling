# Docs assets

Put your project outputs in this folder so the site can link to them from `docs/index.html`.

- `writeup.pdf` — final report PDF
- `software.tar.gz` (or `.zip`) — software bundle / tarball

After adding these files, commit and push to GitHub and the links on the site will work.
