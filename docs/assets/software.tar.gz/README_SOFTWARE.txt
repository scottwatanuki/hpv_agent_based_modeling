Placeholder software tarball for project
